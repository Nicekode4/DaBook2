<?php
class song {
    public $title = "Im the problem";
    public $author = "Lil PP";
    public $rating = 7.4;

    public function showInfo(){
        echo "<br>" . "<br>" . "Title: " . $this->title . "<br>";
        echo "Author: " . $this->author . "<br>";
        echo "Rating: " . $this->rating . "<br>";
    }
}
?>