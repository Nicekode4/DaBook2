<?php 
$myStr = "lel";
$forside;
$about;
?>