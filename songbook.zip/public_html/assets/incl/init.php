<?php
require_once './assets/incl/variables.php';
?>