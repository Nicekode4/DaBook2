<!DOCTYPE html>
<html>
  <head>
     <title><?php echo isset($myStr) ? $myStr : "Min awesome PHP side" ?></title>
     <link rel="stylesheet" href="/assets/css/main.css">
  </head>
  <body>

     <header>
        <nav>
        <a href="index.php"><?php
        echo isset($forside) ? "You here mate!" : "forside"
           ?></a>
                   <a href="about.php"><?php
        echo isset($about) ? "You here mate!" : "about"
           ?></a>

        </nav>
     </header>

     <section id="content">