
<?php
//Define a constant
define("DOCROOT", $_SERVER["DOCUMENT_ROOT"]);
define("COREROOT", str_replace('public_html', 'core/', $_SERVER['DOCUMENT_ROOT'])) ;
require_once(COREROOT . '/classes/autoload.php');
require_once './assets/incl/init.php';
?>

<!-- Header -->
<?php
$forside = "Forside";
$myStr = "Forside";
require_once './assets/incl/header.php';

?>

<!-- Body -->
<?php
echo "Hi";
?>

<!-- Footer -->
<?php
require_once './assets/incl/footer.php';
?>