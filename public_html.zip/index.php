
<?php
require_once './assets/incl/init.php';
?>

<!-- Header -->
<?php
$forside = "Forside";
$myStr = "Forside";
echo Tools::Header($myStr)

?>

<!-- Body -->
<?php
require './assets/incl/body3.php'
?>
<?php

?>
<!-- Footer -->
<?php
echo Tools::Footer();
?>