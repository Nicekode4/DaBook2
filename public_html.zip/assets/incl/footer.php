</section>

<footer>
   <address>Testvej 40, 4040 Testrup</address>
</footer>

<script src="/assets/js/jquery.min.js"></script>
</body>
</html>